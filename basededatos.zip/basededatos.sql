use parcial1base;
show databases;


-- Tabla de Estudiantes
CREATE TABLE Estudiantes (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    NombreCompleto VARCHAR(255) NOT NULL,
    FechaNacimiento DATE NOT NULL,
    Carrera VARCHAR(100) NOT NULL
);

-- Comentario descriptivo
-- Esta tabla almacena información sobre los estudiantes.


-- Tabla de Materias
CREATE TABLE Materias (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    NombreMateria VARCHAR(255) NOT NULL,
    Descripcion VARCHAR(255),
    Carrera VARCHAR(100) NOT NULL,
    CONSTRAINT fk_materia_carrera
        FOREIGN KEY (Carrera) 
        REFERENCES Estudiantes(Carrera)
);

-- Tabla para registrar las materias inscritas por cada estudiante
CREATE TABLE InscripcionMaterias (
    EstudianteID INT,
    MateriaID INT,
    PRIMARY KEY (EstudianteID, MateriaID),
    FOREIGN KEY (EstudianteID) REFERENCES Estudiantes(ID),
    FOREIGN KEY (MateriaID) REFERENCES Materias(ID)
);



-- Comentario descriptivo
-- Esta tabla almacena información sobre las materias.


-- Tabla de Inscripciones de Estudiantes
CREATE TABLE Inscripciones (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    Estudiante_ID INT,
    Materia_Codigo VARCHAR(10),
    Nota FLOAT,
    FOREIGN KEY (Estudiante_ID) REFERENCES Estudiantes(ID),
    FOREIGN KEY (Materia_Codigo) REFERENCES Materias(Codigo),
    -- Comentario descriptivo
    -- Esta tabla registra las inscripciones de los estudiantes en las materias y las notas asociadas.
    INDEX (Estudiante_ID), -- Índice para mejorar el rendimiento de las consultas.
    INDEX (Materia_Codigo) -- Índice para mejorar el rendimiento de las consultas.
);
select * from estudiantes;
select  * from inscripciones;
select * from materias;
select * from inscripcionmaterias;

